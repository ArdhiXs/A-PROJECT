pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
npm install

echo "[!] SUDAH SELESAI TINGGAL node index.js SOB:)"
echo "JANGAN LUPA SUBREK CHANNEL A PROJECT NEW UPDATE:)"
