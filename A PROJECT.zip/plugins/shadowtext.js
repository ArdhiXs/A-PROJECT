let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana Tod?_'
let [kiri] = text.split('|')
await conn.sendFile(m.chat, global.API('https://videfikri.com', '/api/textmaker/shadowtext/', {
 text: kiri,
 theme: 'shadowtext/',
}), 'filename')
}
handler.command = /^shadow$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
