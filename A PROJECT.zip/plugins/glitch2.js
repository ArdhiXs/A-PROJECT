let handler = async (m, { conn, text }) => {
if (!text) throw '*TUTOR DOWNLOAD GAMBAR : #get [linkgambar]*'
let [kiri, kanan] = text.split('|')
await conn.sendFile(m.chat, global.API('https://ardhi-xsquerpants.herokuapp.com', '/api/textmaker', {
 text: kiri,
 text2: kanan,
 theme: 'glitch',
 apikey: 'ardhiganz'
}), 'filename')
}
handler.command = /^glitch2$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
