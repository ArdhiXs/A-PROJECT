let handler  = async (m, { conn, usedPrefix: _p }) => {
  let preview = {}
  try {
    if (!conn.menu) preview = await conn.generateLinkPreview('https://github.com/Nurutomo/wabot-aq')
  } catch (e) {
    if (!conn.menu) preview = await global.conn.generateLinkPreview('https://github.com/Nurutomo/wabot-aq')
  } finally {
    let exp = global.DATABASE.data.users[m.sender].exp
    let name = conn.getName(m.sender)
    let d = new Date
    let locale = 'id-Id'
    let weton = ['Pon','Wage','Kliwon','Legi','Pahing'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })

    let text =  conn.menu ? conn.menu
      .replace(/%p/g, _p)
      .replace(/%exp/g, exp)
      .replace(/%name/g, name)
      .replace(/%weton/g, weton)
      .replace(/%week/g, week)
      .replace(/%date/g, date)
      .replace(/%time/g, time): `
่      *❍━━━━━━━━━━━━━❍*
                *「HAI ARDI」*
      *❍━━━━━━━━━━━━━❍*

┏━━━━━━━━━━━━━━━━━━━━┓
             _${week}, ${date}_
                      _${time}_
┗━━━━━━━━━━━━━━━━━━━━┛
*┏━✪ 《ARDI》 ✪━┓*
*╠➠ ${_p}reset*
*╠➠ ${_p}banchat*
*╠➠ ${_p}unbanchat*
*╠➠ ${_p}bc* [Text]
*╠➠ ${_p}bcgc* [Text]
*╠➠ ${_p}deletechat*
*╠➠ ${_p}deletechat group*
*╠➠ ${_p}mutechat*
*╠➠ ${_p}mutechat group*
*╠➠ ${_p}oadd* [Nomor]
*╠➠ ${_p}opromote* {@user}
*╠➠ ${_p}odemote* {@user}
*╠➠ ${_p}okick* {@user}
*╠➠ ${_p}ohidetag* [Text]
*╠➠ ${_p}setbye* [Text]
*╠➠ ${_p}setmenu* [Text]
*╠➠ ${_p}setmenubefore* [Text]
*╠➠ ${_p}setmenuheader* [Text]
*╠➠ ${_p}setmenubody* [Text]
*╠➠ ${_p}setmenufooter* [Text]
*╠➠ ${_p}setmenuafter* [Text]
*╠➠ ${_p}setwelcome* [Text]
*╠➠ ${_p}update*
*┗━━━━━━━━━━━━━┛*
`.trim()
    conn.reply(m.chat, {...preview, text}, m)
  }
}
handler.command = /^(menuowner?)$/i
handler.owner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
