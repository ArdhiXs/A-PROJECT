let handler = async m => m.reply(`
 اتقوا النار ولو بشق تمرة ، فمن لم يجد فبكلمة طيبةٍ
_“jauhilah api neraka, walau hanya dengan bersedekah sebiji kurma (sedikit)._
_Jika kamu tidak punya, maka bisa dengan kalimah thayyibah”_
*[HR.Bukhari 6539, Muslim 1016]*
╔═══════════════════
║      _*-•4尺 り 1-乃 の ｲ•-*_
╠═══════════════════
║╭─❉ *《DONASI BOS》* ❉──
║│➸ *OVO*: _0882-9405-2009_
║│➸ *DANA*: _0882-9405-2009_
║│➸ *PULSA*: _0882-9405-2009_
║│➸ *GOPAY*: _0882-9405-2009_
║╰──────────────────
╚═══════════════════
`.trim()) 
handler.command = /^donasi$/i

module.exports = handler
