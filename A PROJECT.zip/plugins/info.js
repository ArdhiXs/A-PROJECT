let handler  = async (m, { conn, usedPrefix: _p }) => {
        conn.reply(m.chat, `
┏━────────────━┓
      _*-•4尺 り 1-乃 の ｲ•-*_
┗──────────────┛
╭───❉ *「  INFO 」 * ❉─────•>
╠➥ *IG : https://www.instagram.com/ardhixsquerpants/*
╠➥ *FB : https://www.facebook.com/ardhi.xsquerpants*
╠➥ *Grup : https://chat.whatsapp.com/FrEQ4zgMZG0FMC7VrI7gzK*
╠➥ *Owner : Wa.me/6288294052009*
╠➥ *Author Sc : Nurutomo*
╰──────────────•>
┏━❉ *《HELP》* ❉━┓
╠➠ *${_p}owner*
╠➠ *${_p}donasi*
╠➠ *${_p}grouplist*
╠➠ *${_p}ping*
┗━━━━━━━━━━━┛
`.trim(), m)
}
handler.command = /^info$/i

module.exports = handler
