let limit = 10
let fetch = require('node-fetch')
let handler = async (m, { conn }) => {
 let res = await fetch('https://tobz-api.herokuapp.com/api/husbu2?apikey=BotWeA')
 let { result } = await res.json()
 let hasil = `*NIH TOD HUSBU NYA*`
 conn.sendFile(m.chat, result, 'result.png', hasil, m)
}
handler.command = /^husbu2$/i
handler.group = true
handler.fail = null
handler.limit = true

module.exports = handler
