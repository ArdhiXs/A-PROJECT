let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana Kak?_'
let [kiri, kanan] = text.split('|')
await conn.sendFile(m.chat, global.API('https://api.xteam.xyz', '/textpro/ph', {
 text: kiri,
 text2: kanan,
 theme: 'ph',
 apikey: 'APIKEY'
}), 'filename')
}
handler.command = /^phtext$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
