let fetch = require('node-fetch')
let handler = async (m, { conn }) => {
 let res = await fetch('https://ardhixsquerpants.herokuapp.com/api/infogempa')
 let { lokasi, kedalaman, map, koordinat, magnitude, waktu } = await res.json()
 let hasil = `*INFO GEMPA* \n\ *Lokasi* : _${lokasi}_ \n *Kedalaman* : _${kedalaman}_ \n *Koordinat* : _${koordinat}_ \n *Magnitude* : _${magnitude}_ \n *Waktu* : _${waktu}_`
 conn.sendFile(m.chat, map, 'map.jpg', hasil, m)
}
handler.command = /^infogempa$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
