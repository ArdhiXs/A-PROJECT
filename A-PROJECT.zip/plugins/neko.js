let limit = 10
let fetch = require('node-fetch')
let handler = async (m, { conn }) => {
 let res = await fetch('https://tobz-api.herokuapp.com/api/nsfwneko?apikey=BotWeA')
 let { result } = await res.json()
 let hasil = `*NIH TOD NEKO NYA*`
 conn.sendFile(m.chat, result, 'result.png', hasil, m)
}
handler.command = /^neko$/i
handler.group = true
handler.fail = null
handler.limit = true

module.exports = handler
