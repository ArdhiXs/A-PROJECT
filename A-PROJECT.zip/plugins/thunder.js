let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana Kak?_'
let [aproject] = text.split('|')
await conn.sendFile(m.chat, global.API('http://api.lolhuman.xyz', '/api/textprome/thunder', {
 text: aproject,
 theme: 'thunder',
 apikey: 'APIKEY'
}), 'filename')
}
handler.command = /^thunder$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
