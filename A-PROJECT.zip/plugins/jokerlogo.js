let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana tod?_'
let [aproject] = text.split('|')
await conn.sendFile(m.chat, global.API('https://api.xteam.xyz', '/textpro/jokerlogo', {
 text: aproject,
 theme: 'jokerlogo',
 apikey: 'APIKEY'
}), 'filename')
}
handler.command = /^jokerlogo$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
