let limit = 10
let fetch = require('node-fetch')
let handler = async (m, { conn }) => {
 let res = await fetch('https://ardhixsquerpants.herokuapp.com/api/nekonime')
 let { result } = await res.json()
 let hasil = `*NIH TOD NEKONIME NYA*`
 conn.sendFile(m.chat, result, 'result.jpg', hasil,  m)
}
handler.command = /^nekonime$/i
handler.group = true
handler.fail = null
handler.limit = true

module.exports = handler
