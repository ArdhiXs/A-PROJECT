let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana Kak?_'
let [aproject] = text.split('|')
await conn.sendFile(m.chat, global.API('https://api.xteam.xyz', '/textpro/neon', {
 text: aproject,
 theme: 'neon',
 apikey: 'APIKEY'
}), 'filename')
}
handler.command = /^neon$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
