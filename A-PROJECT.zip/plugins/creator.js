let handler = function (m) {
  // this.sendContact(m.chat, '6281515860089', 'Nurutomo', m)
  this.sendContact(m.chat, '6288294052009', 'MANK ARDI', m)
}
handler.help = ['owner']
handler.tags = ['info']

handler.command = /^owner$/i

module.exports = handler
