let limit = 10
let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana Tod_'
let [cok] = text.split('|')
await conn.sendFile(m.chat, global.API('https://videfikri.com', '/api/textmaker/burnpaper/', {
 text: cok,
 theme: 'burnpaper/',
}), 'filename')
}
handler.command = /^burnpaper$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true

module.exports = handler
