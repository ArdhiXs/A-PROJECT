let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana Tod_'
let [kiri, kanan] = text.split('|')
await conn.sendFile(m.chat, global.API('https://videfikri.com', '/api/textmaker/tiktokeffect/', {
 text1: kiri,
 text2: kanan,
 theme: 'tiktokeffect/',
}), 'filename')
}
handler.command = /^glitch$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
