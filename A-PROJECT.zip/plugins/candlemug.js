let limit = 10
let handler = async (m, { conn, text }) => {
if (!text) throw '_Text nya mana Tod_'
let [aproject] = text.split('|')
await conn.sendFile(m.chat, global.API('https://videfikri.com', '/api/textmaker/candlemug/', {
 text: aproject,
 theme: 'candlemug/',
}), 'filename')
}
handler.command = /^candlemug$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true

module.exports = handler
