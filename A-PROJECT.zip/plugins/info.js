let handler  = async (m, { conn, usedPrefix: _p }) => {
        conn.reply(m.chat, `
┏━────────────━┓
             _*A PROJECT*_
┗──────────────┛
╭───❉ *「  INFO 」 * ❉─────•>
╠➥ *IG : https://tinyurl.com/ycv6dozc*
╠➥ *FB : https://tinyurl.com/y7rsvf8x*
╠➥ *YT : https://bit.ly/3qsDIHz*
╠➥ *Grup : https://bit.ly/3l1qHU1*
╠➥ *Owner : Wa.me/6288294052009*
║
╠❉ *「THANKS TO」* ❉━
╠➥ *Author Sc : Nurutomo*
╠➥ _Api : api.xteam.xyz_
╠➥ _Api : api.lolhuman.xyz_
╠➥ _xteam: blackpink,neon,phtext,glitch,jokerlogo_
╠➥ _lolhuman: glow,thunder_
╰──────────────•>
┏━❉ *《HELP》* ❉━┓
╠➠ *${_p}owner*
╠➠ *${_p}donasi*
╠➠ *${_p}grouplist*
╠➠ *${_p}ping*
┗━━━━━━━━━━━┛
`.trim(), m)
}
handler.command = /^info$/i

module.exports = handler
