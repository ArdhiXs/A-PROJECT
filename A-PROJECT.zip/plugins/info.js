let handler  = async (m, { conn, usedPrefix: _p }) => {
        conn.reply(m.chat, `
┏━────────────━┓
             _*A PROJECT*_
┗──────────────┛
╭───❉ *「  INFO 」 * ❉─────•>
╠➥ *IG : https://www.instagram.com/ardhixsquerpants/*
╠➥ *FB : https://www.facebook.com/ardhi.xsquerpants*
╠➥ *YT : https://youtube.com/channel/UC0Dsp_36EJuUNZpG-Jaa4bg*
╠➥ *Grup : https://chat.whatsapp.com/FrEQ4zgMZG0FMC7VrI7gzK*
╠➥ *Owner : Wa.me/6288294052009*
║
╠❉ *「THANKS TO」* ❉━
╠➥ *Author Sc : Nurutomo*
╠➥ _Api : api.xteam.xyz_
╠➥ _Api : api.lolhuman.xyz_
╠➥ _xteam: blackpink,neon,phtext,glitch,jokerlogo_
╠➥ _lolhuman: glow,thunder_
╰──────────────•>
┏━❉ *《HELP》* ❉━┓
╠➠ *${_p}owner*
╠➠ *${_p}donasi*
╠➠ *${_p}grouplist*
╠➠ *${_p}ping*
┗━━━━━━━━━━━┛
`.trim(), m)
}
handler.command = /^info$/i

module.exports = handler
